<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Not now</name>
   <tag></tag>
   <elementGuidId>ddfa83ae-c2d9-43c7-87d8-c4f2fa17fa27</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-column.a-span12.a-text-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='auth-account-fixup-phone-form']/div/div[5]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cdc4f667-266d-4850-982e-2efed53daeee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-column a-span12 a-text-center</value>
      <webElementGuid>8de1b339-5007-4db2-a03f-fb11c9db8403</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                  Not now
                
              </value>
      <webElementGuid>95f6297d-7887-4490-b6f2-8f75c8a0f06e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-account-fixup-phone-form&quot;)/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-row a-spacing-top-small&quot;]/div[@class=&quot;a-column a-span12 a-text-center&quot;]</value>
      <webElementGuid>ea6e50e2-7110-4d2a-ac52-024850be6cfd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='auth-account-fixup-phone-form']/div/div[5]/div</value>
      <webElementGuid>24d407f6-952e-40f5-97a7-1fda0270542a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div</value>
      <webElementGuid>6ac32b3f-6449-428a-b32c-5f94b79bafcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                  Not now
                
              ' or . = '
                
                  Not now
                
              ')]</value>
      <webElementGuid>5c9a0a4d-f650-4a9d-99e3-076b50128635</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
