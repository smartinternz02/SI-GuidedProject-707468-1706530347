<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_There was a problem                    _73cbc7</name>
   <tag></tag>
   <elementGuidId>eb037ef0-63f2-443a-af47-4901b8c4316d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-padding-medium.auth-workflow</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>27f9f72d-41ec-4699-86ed-ae454b03685d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-padding-medium auth-workflow</value>
      <webElementGuid>339add48-2bbb-4e33-8c40-d9bcfe3c3604</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      
        






  
    

    
      



  
  

  
  


    
  



      

      
        
          
          
            
              






  
    
      




  







  
    

    There was a problem
      
        
          
        
        
      
      
        
          
            We cannot find an account with that email address
          
        
      
    
  

  

  

  
  
  



  
    &lt;div id=&quot;auth-js-alert-box&quot; class=&quot;a-box a-alert a-alert-error auth-client-side-message-box a-spacing-base&quot; role=&quot;alert&quot;>&lt;div class=&quot;a-box-inner a-alert-container&quot;>&lt;i class=&quot;a-icon a-icon-alert&quot;>&lt;/i>&lt;div class=&quot;a-alert-content&quot;>
      This site requires JavaScript to function correctly. Please enable JavaScript on your browser to continue.
    &lt;/div>&lt;/div>&lt;/div>
  




    
    
  



  





















Passkey error
  
    Something went wrong, please sign-in another way or follow any instructions provided by your device.
  
  
    Sorry, your passkey isn't working. There might be a problem with the server. Sign in with your password or try your passkey again later.
  
  



  
    






  
    
    
      
      

      




  
    
  
    
  
    
  
    
  



      
        
          
            Sign in
          
          
          
          
            
              Email or mobile phone number
            
            
            
              
              
                
              
            
            

            
            
            




  Enter your email or mobile phone number


          

          
          

          
            
            









            
            
              Continue
            

            
            
              




  By continuing, you agree to Amazon's Conditions of Use and Privacy Notice.
 

            

            

  function cf() {
    if (typeof window.uet === 'function') {
      uet('cf');
    }
    if (window.embedNotification &amp;&amp;
      typeof window.embedNotification.onCF === 'function') {
      embedNotification.onCF();
    }
  }


cf()

          

          

          

          




  
    
      Need help?
    
    
      
        



  
  
    
  


  Forgot your password?

      
    
    
      
        Other issues with Sign-In
      
    
  



          




  
  
  
    
      
      
      
        
        
      
    
  


          
          

          






          
            




    
    
        
            Buying for work?
        
    

    
        
            Shop on Amazon Business
        
    

          
        
      
    
  
  
    
    
      
        
        New to Amazon?
        
          Create your Amazon account
        
      
    
  

  



  
  


            
          
        
      

      
      
      

      
        






  

  
    
      
        
      

      
    

    
      Conditions of Use
    
    
  
    
      
        
      

      
    

    
      Privacy Notice
    
    
  
    
      
        
      

      
    

    
      Help
    
    
  

  






  






  © 1996-2024, Amazon.com, Inc. or its affiliates




      
    </value>
      <webElementGuid>395bd26e-ddae-4e01-b029-01bc5064343e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-section a-padding-medium auth-workflow&quot;]</value>
      <webElementGuid>0f16f532-22c2-423f-971e-205d605d5d35</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div</value>
      <webElementGuid>887854a4-675b-4328-937a-32c1c1ee2527</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div</value>
      <webElementGuid>c99f1a73-64c0-4398-ac19-684dcecf5aa6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
      
        






  
    

    
      



  
  

  
  


    
  



      

      
        
          
          
            
              






  
    
      




  







  
    

    There was a problem
      
        
          
        
        
      
      
        
          
            We cannot find an account with that email address
          
        
      
    
  

  

  

  
  
  



  
    &lt;div id=&quot;auth-js-alert-box&quot; class=&quot;a-box a-alert a-alert-error auth-client-side-message-box a-spacing-base&quot; role=&quot;alert&quot;>&lt;div class=&quot;a-box-inner a-alert-container&quot;>&lt;i class=&quot;a-icon a-icon-alert&quot;>&lt;/i>&lt;div class=&quot;a-alert-content&quot;>
      This site requires JavaScript to function correctly. Please enable JavaScript on your browser to continue.
    &lt;/div>&lt;/div>&lt;/div>
  




    
    
  



  





















Passkey error
  
    Something went wrong, please sign-in another way or follow any instructions provided by your device.
  
  
    Sorry, your passkey isn&quot; , &quot;'&quot; , &quot;t working. There might be a problem with the server. Sign in with your password or try your passkey again later.
  
  



  
    






  
    
    
      
      

      




  
    
  
    
  
    
  
    
  



      
        
          
            Sign in
          
          
          
          
            
              Email or mobile phone number
            
            
            
              
              
                
              
            
            

            
            
            




  Enter your email or mobile phone number


          

          
          

          
            
            









            
            
              Continue
            

            
            
              




  By continuing, you agree to Amazon&quot; , &quot;'&quot; , &quot;s Conditions of Use and Privacy Notice.
 

            

            

  function cf() {
    if (typeof window.uet === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      uet(&quot; , &quot;'&quot; , &quot;cf&quot; , &quot;'&quot; , &quot;);
    }
    if (window.embedNotification &amp;&amp;
      typeof window.embedNotification.onCF === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      embedNotification.onCF();
    }
  }


cf()

          

          

          

          




  
    
      Need help?
    
    
      
        



  
  
    
  


  Forgot your password?

      
    
    
      
        Other issues with Sign-In
      
    
  



          




  
  
  
    
      
      
      
        
        
      
    
  


          
          

          






          
            




    
    
        
            Buying for work?
        
    

    
        
            Shop on Amazon Business
        
    

          
        
      
    
  
  
    
    
      
        
        New to Amazon?
        
          Create your Amazon account
        
      
    
  

  



  
  


            
          
        
      

      
      
      

      
        






  

  
    
      
        
      

      
    

    
      Conditions of Use
    
    
  
    
      
        
      

      
    

    
      Privacy Notice
    
    
  
    
      
        
      

      
    

    
      Help
    
    
  

  






  






  © 1996-2024, Amazon.com, Inc. or its affiliates




      
    &quot;) or . = concat(&quot;
      
        






  
    

    
      



  
  

  
  


    
  



      

      
        
          
          
            
              






  
    
      




  







  
    

    There was a problem
      
        
          
        
        
      
      
        
          
            We cannot find an account with that email address
          
        
      
    
  

  

  

  
  
  



  
    &lt;div id=&quot;auth-js-alert-box&quot; class=&quot;a-box a-alert a-alert-error auth-client-side-message-box a-spacing-base&quot; role=&quot;alert&quot;>&lt;div class=&quot;a-box-inner a-alert-container&quot;>&lt;i class=&quot;a-icon a-icon-alert&quot;>&lt;/i>&lt;div class=&quot;a-alert-content&quot;>
      This site requires JavaScript to function correctly. Please enable JavaScript on your browser to continue.
    &lt;/div>&lt;/div>&lt;/div>
  




    
    
  



  





















Passkey error
  
    Something went wrong, please sign-in another way or follow any instructions provided by your device.
  
  
    Sorry, your passkey isn&quot; , &quot;'&quot; , &quot;t working. There might be a problem with the server. Sign in with your password or try your passkey again later.
  
  



  
    






  
    
    
      
      

      




  
    
  
    
  
    
  
    
  



      
        
          
            Sign in
          
          
          
          
            
              Email or mobile phone number
            
            
            
              
              
                
              
            
            

            
            
            




  Enter your email or mobile phone number


          

          
          

          
            
            









            
            
              Continue
            

            
            
              




  By continuing, you agree to Amazon&quot; , &quot;'&quot; , &quot;s Conditions of Use and Privacy Notice.
 

            

            

  function cf() {
    if (typeof window.uet === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      uet(&quot; , &quot;'&quot; , &quot;cf&quot; , &quot;'&quot; , &quot;);
    }
    if (window.embedNotification &amp;&amp;
      typeof window.embedNotification.onCF === &quot; , &quot;'&quot; , &quot;function&quot; , &quot;'&quot; , &quot;) {
      embedNotification.onCF();
    }
  }


cf()

          

          

          

          




  
    
      Need help?
    
    
      
        



  
  
    
  


  Forgot your password?

      
    
    
      
        Other issues with Sign-In
      
    
  



          




  
  
  
    
      
      
      
        
        
      
    
  


          
          

          






          
            




    
    
        
            Buying for work?
        
    

    
        
            Shop on Amazon Business
        
    

          
        
      
    
  
  
    
    
      
        
        New to Amazon?
        
          Create your Amazon account
        
      
    
  

  



  
  


            
          
        
      

      
      
      

      
        






  

  
    
      
        
      

      
    

    
      Conditions of Use
    
    
  
    
      
        
      

      
    

    
      Privacy Notice
    
    
  
    
      
        
      

      
    

    
      Help
    
    
  

  






  






  © 1996-2024, Amazon.com, Inc. or its affiliates




      
    &quot;))]</value>
      <webElementGuid>d4242111-f877-4931-a535-f8477ed339f9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
