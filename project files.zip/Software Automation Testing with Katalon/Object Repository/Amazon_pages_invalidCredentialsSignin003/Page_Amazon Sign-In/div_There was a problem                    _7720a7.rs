<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_There was a problem                    _7720a7</name>
   <tag></tag>
   <elementGuidId>acb600a4-3eeb-4a3c-ae3a-2c9d5123b3bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='auth-error-message-box']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-box-inner.a-alert-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a86ad764-6af3-47e3-bda7-a4d8214c5c32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner a-alert-container</value>
      <webElementGuid>b8e518e0-d627-4fce-a722-2e63634e10f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>There was a problem
      
        
          
        
        
      
      
        
          
            We cannot find an account with that email address
          
        
      
    </value>
      <webElementGuid>2f99c5b9-6e69-4be7-b551-82144400d43b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]</value>
      <webElementGuid>e62af29e-a5bb-49b2-999e-fd8a25a4230b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div</value>
      <webElementGuid>7ee57713-ca7a-4540-af68-9368e85bdb9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div</value>
      <webElementGuid>2953f870-0405-4975-a8a3-c742a750d6d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'There was a problem
      
        
          
        
        
      
      
        
          
            We cannot find an account with that email address
          
        
      
    ' or . = 'There was a problem
      
        
          
        
        
      
      
        
          
            We cannot find an account with that email address
          
        
      
    ')]</value>
      <webElementGuid>64740630-65ec-443c-ba0a-454da6bed7b3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
