<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Weve sent a One Time Password (OTP) to_af2fc8</name>
   <tag></tag>
   <elementGuidId>0d0aee92-8bc3-43f5-8214-bbb9bc4e0232</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='verification-code-form']/div/div[2]/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c8f01335-e98f-4190-b5e6-5c5bbb5d38c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>We've sent a One Time Password (OTP) to the email
 hariniguggilla.123@gmail.com. </value>
      <webElementGuid>9a9bc7b0-4041-4cf4-af57-e0d7a372c954</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;verification-code-form&quot;)/div[@class=&quot;a-row a-spacing-small&quot;]/div[@class=&quot;a-row a-spacing-none&quot;]/span[2]</value>
      <webElementGuid>d8b554c7-b085-4510-84bf-d77984ca3f74</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='verification-code-form']/div/div[2]/span[2]</value>
      <webElementGuid>2ae8afd5-b85d-481d-8b0f-10ea091291bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]</value>
      <webElementGuid>8e69d296-c4ed-49f5-bf6e-eae06c5c2092</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = concat(&quot;We&quot; , &quot;'&quot; , &quot;ve sent a One Time Password (OTP) to the email
 hariniguggilla.123@gmail.com. &quot;) or . = concat(&quot;We&quot; , &quot;'&quot; , &quot;ve sent a One Time Password (OTP) to the email
 hariniguggilla.123@gmail.com. &quot;))]</value>
      <webElementGuid>a4cde54c-7e8c-4ebf-bc38-74076a4570b3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
