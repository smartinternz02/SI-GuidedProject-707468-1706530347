<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Password assistance</name>
   <tag></tag>
   <elementGuidId>69e51b44-049d-4603-b4f1-e3dd305df935</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='authportal-main-section']/div[2]/div/div/div/form/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>6e8b08f2-abf4-457c-9c31-84e2b0ebaf7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Password assistance
      </value>
      <webElementGuid>26cecb2d-db0d-4004-858b-450dfc29f0ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authportal-main-section&quot;)/div[@class=&quot;a-section auth-pagelet-container&quot;]/div[@class=&quot;a-section a-spacing-double-large&quot;]/div[@class=&quot;a-box a-spacing-base&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/form[@class=&quot;auth-validate-form auth-real-time-validation a-spacing-none&quot;]/h1[1]</value>
      <webElementGuid>c17acbf6-61f5-4016-8d43-f143c546a3fb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='authportal-main-section']/div[2]/div/div/div/form/h1</value>
      <webElementGuid>89fa16a0-b283-4f4e-aa20-08213e07ed60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>ece919bf-0671-4e5f-80e6-befa08106219</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
        Password assistance
      ' or . = '
        Password assistance
      ')]</value>
      <webElementGuid>f8c45a54-69ed-4df1-b2ca-a3a878ee6ee5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
