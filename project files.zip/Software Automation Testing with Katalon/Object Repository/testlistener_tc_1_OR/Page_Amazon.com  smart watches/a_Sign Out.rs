<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign Out</name>
   <tag></tag>
   <elementGuidId>73eeca51-85a8-427b-a2f6-5e65d38c4df4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@onclick=&quot;$Nav.getNow('signInRedirect')('nav_em_hd_re_signin', '/gp/flex/sign-out.html?action=sign-out&amp;path=%2Fgp%2Fhomepage.html%3F_encoding%3DUTF8%26ref_%3Dnavm_em_signin&amp;signIn=1&amp;useRedirectOnSuccess=1&amp;ref_=nav_em_signout_0_1_1_39', 'nav_em_hd_clc_signin_0_1_1_39')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(25) > a.hmenu-item</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e31790e0-dfd7-4c57-9d89-90eab1efb97f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hmenu-item</value>
      <webElementGuid>565d7ff9-d5ae-4a67-a4d7-7a5c6c3f0fa9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>javascript:void(0)</value>
      <webElementGuid>f16397d5-5bdd-4fd8-b85b-f859af6cdd1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>$Nav.getNow('signInRedirect')('nav_em_hd_re_signin', '/gp/flex/sign-out.html?action=sign-out&amp;path=%2Fgp%2Fhomepage.html%3F_encoding%3DUTF8%26ref_%3Dnavm_em_signin&amp;signIn=1&amp;useRedirectOnSuccess=1&amp;ref_=nav_em_signout_0_1_1_39', 'nav_em_hd_clc_signin_0_1_1_39')</value>
      <webElementGuid>6d9a934c-550a-4606-a1d4-f8aaaed095c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign Out</value>
      <webElementGuid>708bdb50-cf8f-4cbc-8c78-b2b3183505df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible&quot;]/li[25]/a[@class=&quot;hmenu-item&quot;]</value>
      <webElementGuid>39a6078a-8a23-43db-af90-533384d3fa0f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@onclick=&quot;$Nav.getNow('signInRedirect')('nav_em_hd_re_signin', '/gp/flex/sign-out.html?action=sign-out&amp;path=%2Fgp%2Fhomepage.html%3F_encoding%3DUTF8%26ref_%3Dnavm_em_signin&amp;signIn=1&amp;useRedirectOnSuccess=1&amp;ref_=nav_em_signout_0_1_1_39', 'nav_em_hd_clc_signin_0_1_1_39')&quot;]</value>
      <webElementGuid>f4e972d7-eb6f-4d72-bfe4-6ea0ce8d604d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[25]/a</value>
      <webElementGuid>83556c73-593a-4027-bde4-853b06579f13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Sign Out')])[2]</value>
      <webElementGuid>1db10ba9-32f6-47d6-99d2-00072e412d15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'javascript:void(0)')])[46]</value>
      <webElementGuid>56139f99-d898-40ec-aca4-a72cc96d3d35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[25]/a</value>
      <webElementGuid>4de19eb9-558b-47d3-91dd-19edee358d92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'javascript:void(0)' and (text() = 'Sign Out' or . = 'Sign Out')]</value>
      <webElementGuid>262f6b9b-625d-4ff1-b479-c2fc3b7fe342</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
